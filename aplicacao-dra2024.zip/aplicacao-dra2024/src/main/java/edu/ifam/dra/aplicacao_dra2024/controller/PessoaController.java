package edu.ifam.dra.aplicacao_dra2024.controller;

import edu.ifam.dra.aplicacao_dra2024.Service.PessoaService;
import edu.ifam.dra.aplicacao_dra2024.dto.PessoaOutputDTO;
import edu.ifam.dra.aplicacao_dra2024.model.Pessoa;
import edu.ifam.dra.aplicacao_dra2024.repository.PessoaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/pessoa")
public class PessoaController {

    @Autowired
    private PessoaRepository pessoaRepository;
    @Autowired
    private PessoaService pessoaService;

    @GetMapping
    public ResponseEntity<List<PessoaOutputDTO>> list(){

        List<PessoaOutputDTO> pessoasDTO = pessoaService.list();
        if(!pessoasDTO.isEmpty()){
            return new ResponseEntity<>(pessoasDTO, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }

    @PostMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Pessoa> create(@RequestBody Pessoa pessoa){
        try{
            pessoaRepository.save(pessoa);
            return new ResponseEntity<>(pessoa, HttpStatus.CREATED);
        }catch(Exception ex){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value ="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PessoaOutputDTO> getById(@PathVariable Long id){
        Optional<Pessoa> pessoa = pessoaRepository.findById(id);
        PessoaOutputDTO pessoaDTO = new PessoaOutputDTO(pessoa.get());
        if(pessoa.isPresent()){
            return new ResponseEntity<>(pessoaDTO, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping(value ="/{id}")
    public ResponseEntity<Pessoa> deleteById(@PathVariable Long id){
        Optional<Pessoa> pessoa = pessoaRepository.findById(id);
        if(pessoa.isPresent()){
            pessoaRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @PutMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Pessoa> alter(@RequestBody Pessoa pessoa){
        Optional<Pessoa> p = pessoaRepository.findById(pessoa.getId());
        if(p.isPresent()){
            Pessoa p1 = p.get();
            p1.setNome(pessoa.getNome());
            p1.setEmail(pessoa.getEmail());
            p1.setCidade(pessoa.getCidade());
            Pessoa pessoaSalvaNoBD = pessoaRepository.save(p1);
            return new ResponseEntity<>(pessoaSalvaNoBD,HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
